package poe.part.pkg1;

public class Login {

    public static final String MSG_SUCCESS = "Registration successful.";

    public static final String MSG_BAD_USERNAME =
            "Username is not correctly formatted, please ensure that your username "
            + "contains an underscore and is no more than five characters in length.";

    public static final String MSG_BAD_PASSWORD =
            "Password is not correctly formatted; please ensure that the password "
            + "contains at least eight characters, a capital letter, a number, "
            + "and a special character.";

    public static final String MSG_BAD_CELL =
            "Cell phone number incorrectly formatted or does not contain "
            + "international code.";

    private String firstName;
    private String lastName;
    private String username;
    private String password;
    private String cellPhoneNumber;

    private boolean loginSuccessful;

    public Login(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    // Checks the username
    public boolean checkUserName(String username) {

        if (username == null) {
            return false;
        }

        if (!username.contains("_")) {
            return false;
        }

        if (username.length() > 5) {
            return false;
        }

        return true;
    }

    // Checks the password
    public boolean checkPasswordComplexity(String password) {

        if (password == null || password.length() < 8) {
            return false;
        }

        boolean capital = false;
        boolean number = false;
        boolean special = false;

        for (int i = 0; i < password.length(); i++) {

            char letter = password.charAt(i);

            if (Character.isUpperCase(letter)) {
                capital = true;
            }

            if (Character.isDigit(letter)) {
                number = true;
            }

            if (!Character.isLetterOrDigit(letter)) {
                special = true;
            }
        }

        if (capital && number && special) {
            return true;
        }

        return false;
    }

    // Checks the cellphone number
    public boolean checkCellPhoneNumber(String cellPhoneNumber) {

        if (cellPhoneNumber == null) {
            return false;
        }

        if (!cellPhoneNumber.startsWith("+27")) {
            return false;
        }

        if (cellPhoneNumber.length() != 12) {
            return false;
        }

        for (int i = 3; i < cellPhoneNumber.length(); i++) {

            if (!Character.isDigit(cellPhoneNumber.charAt(i))) {
                return false;
            }
        }

        return true;
    }

    // Registers the user
    public String registerUser(String username, String password,
            String cellPhoneNumber, String firstName, String lastName) {

        if (!checkUserName(username)) {
            return MSG_BAD_USERNAME;
        }

        if (!checkPasswordComplexity(password)) {
            return MSG_BAD_PASSWORD;
        }

        if (!checkCellPhoneNumber(cellPhoneNumber)) {
            return MSG_BAD_CELL;
        }

        this.username = username;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;
        this.firstName = firstName;
        this.lastName = lastName;

        return MSG_SUCCESS;
    }

    // Checks username and password
    public boolean loginUser(String enteredUsername, String enteredPassword) {

        if (username != null
                && password != null
                && username.equals(enteredUsername)
                && password.equals(enteredPassword)) {

            loginSuccessful = true;
        } else {
            loginSuccessful = false;
        }

        return loginSuccessful;
    }

    // Displays login message
    public String returnLoginStatus(String enteredUsername, String enteredPassword) {

        if (loginUser(enteredUsername, enteredPassword)) {
            return "Welcome " + firstName + " " + lastName
                    + " it is great to see you again.";
        }

        return "Username or password incorrect, please try again.";
    }

    public boolean isLoginSuccessful() {
        return loginSuccessful;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getUsername() {
        return username;
    }

    public String getCellPhoneNumber() {
        return cellPhoneNumber;
    }
}