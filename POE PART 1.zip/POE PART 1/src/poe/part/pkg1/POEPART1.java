package poe.part.pkg1;

import java.util.Scanner;

public class POEPART1 {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("========== REGISTER ==========");

        System.out.println("Enter your first name: ");
        String firstName = scan.nextLine();

        System.out.println("Enter your last name: ");
        String lastName = scan.nextLine();

        Login login = new Login(firstName, lastName);

        String result;

        do {
            System.out.println("Enter username: ");
            String username = scan.nextLine();

            System.out.println("Enter password: ");
            String password = scan.nextLine();

            System.out.println("Enter cellphone number starting with +27: ");
            String cellNumber = scan.nextLine();

            result = login.registerUser(
                    username,
                    password,
                    cellNumber,
                    firstName,
                    lastName
            );

            System.out.println(result);

            if (!result.equals("Registration successful.")) {
                System.out.println("Please try again.\n");
            }

        } while (!result.equals("Registration successful."));

        System.out.println("\n========== LOGIN ==========");

        System.out.print("Enter username: ");
        String username = scan.nextLine();

        System.out.print("Enter password: ");
        String password = scan.nextLine();

        System.out.println(login.returnLoginStatus(username, password));

        scan.close();
    }
}
