package poe.part.pkg1;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class LoginTest {

    private Login login;

    @Before
    public void setUp() {
        login = new Login("Kyle", "Smith");
    }

    @After
    public void tearDown() {
        login = null;
    }

    @Test
    public void testCheckUserName() {

        assertTrue(login.checkUserName("kyl_1"));

        assertFalse(login.checkUserName("kyle!!!!!!!"));
    }

    @Test
    public void testCheckPasswordComplexity() {

        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));

        assertFalse(login.checkPasswordComplexity("password"));
    }

    @Test
    public void testCheckCellPhoneNumber() {

        assertTrue(login.checkCellPhoneNumber("+27838968976"));

        assertFalse(login.checkCellPhoneNumber("08966553"));
    }

    @Test
    public void testRegisterUser() {

        String result;

        // Correct information
        result = login.registerUser(
                "kyl_1",
                "Ch&&sec@ke99!",
                "+27838968976",
                "Kyle",
                "Smith"
        );

        assertEquals("Registration successful.", result);

        // Incorrect username
        result = login.registerUser(
                "kyle!!!!!!!",
                "Ch&&sec@ke99!",
                "+27838968976",
                "Kyle",
                "Smith"
        );

        assertEquals(
                "Username is not correctly formatted, please ensure that your username "
                + "contains an underscore and is no more than five characters in length.",
                result
        );

        // Incorrect password
        result = login.registerUser(
                "kyl_1",
                "password",
                "+27838968976",
                "Kyle",
                "Smith"
        );

        assertEquals(
                "Password is not correctly formatted; please ensure that the password "
                + "contains at least eight characters, a capital letter, a number, "
                + "and a special character.",
                result
        );

        // Incorrect cellphone number
        result = login.registerUser(
                "kyl_1",
                "Ch&&sec@ke99!",
                "08966553",
                "Kyle",
                "Smith"
        );

        assertEquals(
                "Cell phone number incorrectly formatted or does not contain "
                + "international code.",
                result
        );
    }

    @Test
    public void testLoginUser() {

        login.registerUser(
                "kyl_1",
                "Ch&&sec@ke99!",
                "+27838968976",
                "Kyle",
                "Smith"
        );

        assertTrue(
                login.loginUser("kyl_1", "Ch&&sec@ke99!")
        );

        assertFalse(
                login.loginUser("wrong", "wrongpass")
        );
    }

    @Test
    public void testReturnLoginStatus() {

        login.registerUser(
                "kyl_1",
                "Ch&&sec@ke99!",
                "+27838968976",
                "Kyle",
                "Smith"
        );

        String result;

        result = login.returnLoginStatus(
                "kyl_1",
                "Ch&&sec@ke99!"
        );

        assertEquals(
                "Welcome Kyle Smith it is great to see you again.",
                result
        );

        result = login.returnLoginStatus(
                "wrong",
                "wrongpass"
        );

        assertEquals(
                "Username or password incorrect, please try again.",
                result
        );
    }
}
