package poe.part.pkg1;

/**
 * Handles user registration, validation and login.
 */
public class Login {

    public static final String MSG_SUCCESS = "Registration successful.";

    public static final String MSG_BAD_USERNAME =
            "Username is not correctly formatted, please ensure that your username "
            + "contains an underscore and is no more than five characters in length.";

    public static final String MSG_BAD_PASSWORD =
            "Password is not correctly formatted; please ensure that the password "
            + "contains at least eight characters, a capital letter, a number, "
            + "and a special character.";

    public static final String MSG_BAD_CELL =
            "Cell phone number incorrectly formatted or does not contain "
            + "international code.";

    private String firstName;
    private String lastName;
    private String username;
    private String password;
    private String cellphone;
    private boolean loginSuccessful;

    public Login(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.loginSuccessful = false;
    }

    public boolean checkUserName(String username) {
        return username != null
                && username.contains("_")
                && username.length() <= 5;
    }

    public boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) {
            return false;
        }

        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;

        for (int i = 0; i < password.length(); i++) {
            char character = password.charAt(i);

            if (Character.isUpperCase(character)) {
                hasCapital = true;
            }
            if (Character.isDigit(character)) {
                hasNumber = true;
            }
            if (!Character.isLetterOrDigit(character)) {
                hasSpecial = true;
            }
        }

        return hasCapital && hasNumber && hasSpecial;
    }

    public boolean checkCellPhoneNumber(String cellphone) {
        return cellphone != null && cellphone.matches("\\+27[0-9]{9}");
    }

    public String registerUser(String username, String password,
            String cellphone, String firstName, String lastName) {

        if (!checkUserName(username)) {
            return MSG_BAD_USERNAME;
        }

        if (!checkPasswordComplexity(password)) {
            return MSG_BAD_PASSWORD;
        }

        if (!checkCellPhoneNumber(cellphone)) {
            return MSG_BAD_CELL;
        }

        this.username = username;
        this.password = password;
        this.cellphone = cellphone;
        this.firstName = firstName;
        this.lastName = lastName;
        this.loginSuccessful = false;

        return MSG_SUCCESS;
    }

    public boolean loginUser(String enteredUsername, String enteredPassword) {
        loginSuccessful = username != null
                && password != null
                && username.equals(enteredUsername)
                && password.equals(enteredPassword);

        return loginSuccessful;
    }

    public String returnLoginStatus(String enteredUsername, String enteredPassword) {
        if (loginUser(enteredUsername, enteredPassword)) {
            return "Welcome " + firstName + " " + lastName
                    + " it is great to see you again.";
        }

        return "Username or password incorrect, please try again.";
    }

    public boolean isLoginSuccessful() {
        return loginSuccessful;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getUsername() {
        return username;
    }

    public String getCellPhoneNumber() {
        return cellphone;
    }
}
