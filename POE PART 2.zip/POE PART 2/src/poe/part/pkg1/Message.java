package poe.part.pkg1;

import java.security.SecureRandom;

/**
 * Represents one QuickChat message.
 * This class is also used by the Messages class, so both message versions
 * share the same message ID, recipient, text and hash.
 */
public class Message {

    private static final SecureRandom RANDOM = new SecureRandom();

    private final String messageId;
    private final String recipient;
    private final String text;
    private final String messageHash;
    private final int messageNumber;

    // Used by the main QuickChat application.
    public Message(String recipient, String text) {
        this(0, recipient, text);
    }

    // Used when a message number is available, including MessagesTest.
    public Message(int messageNumber, String recipient, String text) {
        this.messageId = createMessageId();
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.text = text;
        this.messageHash = CreateMessageHash(messageId, messageNumber, text);
    }

    // Creates a 10-digit message ID.
    private String createMessageId() {
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(RANDOM.nextInt(10));
        }
        return id.toString();
    }

    // Hash format: first two ID digits, message number, first and last words.
    private String CreateMessageHash(String id, int number, String message) {
        String firstWord = "";
        String lastWord = "";

        if (message != null && !message.trim().isEmpty()) {
            String[] words = message.trim().split("\\s+");
            firstWord = cleanWord(words[0]);
            lastWord = cleanWord(words[words.length - 1]);
        }

        return id.substring(0, 2) + ":" + number + ":" + firstWord + lastWord;
    }

    private String cleanWord(String word) {
        return word.replaceAll("[^A-Za-z0-9]", "").toUpperCase();
    }

    public String getMessageId() { return messageId; }
    public String getMessageID() { return messageId; }
    public String getRecipient() { return recipient; }
    public String getText() { return text; }
    public String getMessageText() { return text; }
    public String getMessageHash() { return messageHash; }
    public int getMessageNumber() { return messageNumber; }

    @Override
    public String toString() {
        return "Message ID: " + messageId
                + "\nRecipient: " + recipient
                + "\nMessage: " + text
                + "\nMessage Hash: " + messageHash;
    }
}
