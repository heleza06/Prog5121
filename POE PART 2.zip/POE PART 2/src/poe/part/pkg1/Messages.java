package poe.part.pkg1;

public class Messages {

    public static final int SEND = 1;
    public static final int DISREGARD = 2;
    public static final int STORE = 3;

    private static int totalMessages = 0;

    private final Message message;
    private final int messageNumber;

    public Messages(int messageNumber, String recipient, String messageText) {
        this.messageNumber = messageNumber;
        this.message = new Message(messageNumber, recipient, messageText);
    }

    public boolean checkMessageID() {
        String id = message.getMessageId();
        return id != null && id.matches("[0-9]{1,10}");
    }

    public static boolean checkRecipientCell(String cellNumber) {
        return cellNumber != null && cellNumber.matches("\\+27[0-9]{9}");
    }

    public static String checkMessageLength(String text) {
        if (text == null || text.length() <= 250) {
            return "Message ready to send.";
        }
        int extraCharacters = text.length() - 250;
        return "Message exceeds 250 characters by " + extraCharacters
                + ", please reduce size.";
    }

    // Hash format: <first 2 chars of ID>:<message number>:<FIRSTWORDLASTWORD>
    public String CreateMessageHash() {
        String id = message.getMessageId();
        String idPart = (id == null) ? "" : id.substring(0, Math.min(2, id.length()));

        String text = message.getText();
        String trimmed = (text == null) ? "" : text.trim();
        String body = "";

        if (!trimmed.isEmpty()) {
            String[] words = trimmed.split("\\s+");
            String first = clean(words[0]);
            String last = clean(words[words.length - 1]);
            body = (words.length == 1) ? first : first + last;
        }
        return idPart + ":" + messageNumber + ":" + body;
    }

    private static String clean(String word) {
        return word.replaceAll("[^A-Za-z0-9]", "").toUpperCase();
    }

    public String sentMessage(int choice) {
        if (choice == SEND) {
            totalMessages++;
            return "Message successfully sent.";
        } else if (choice == DISREGARD) {
            return "Message disregarded.";
        } else if (choice == STORE) {
            return "Message successfully stored.";
        }
        return "Invalid choice. Please enter 1, 2 or 3.";
    }

    public static int returnTotalMessages() {
        return totalMessages;
    }

    // Built here so it always contains the ID, hash, recipient and text.
    public String printMessage() {
        return "Message ID: " + getMessageID()
                + "\nMessage Hash: " + getMessageHash()
                + "\nRecipient: " + getRecipient()
                + "\nMessage: " + getMessageText();
    }

    public String getMessageID() { return message.getMessageId(); }
    public int getMessageNumber() { return messageNumber; }
    public String getRecipient() { return message.getRecipient(); }
    public String getMessageText() { return message.getText(); }

    // Same value as CreateMessageHash(), so the two can never disagree.
    public String getMessageHash() { return CreateMessageHash(); }

    public Message getMessage() { return message; }
}