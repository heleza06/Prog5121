package poe.part.pkg1;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * This is the main class of the QuickChat program.
 * It runs registration, login, the menu and messaging.
 */
public class POEPART1 {

    // A Scanner reads information typed by the user.
    private Scanner input = new Scanner(System.in);

    // These lists remember messages while the program is running.
    private ArrayList<Message> sentMessages = new ArrayList<Message>();
    private ArrayList<Message> storedMessages = new ArrayList<Message>();

    // This object manages registration and login.
    private Login user;

    // The program starts here.
    public static void main(String[] args) {
        POEPART1 program = new POEPART1();
        program.startProgram();
    }

    // Runs the main steps in order.
    public void startProgram() {
        registerUser();
        loginUser();

        System.out.println("\nWelcome to QuickChat!");

        // Keep showing the menu until the user chooses Quit.
        boolean running = true;

        while (running) {
            showMenu();

            String choice = input.nextLine();

            if (choice.equals("1")) {
                sendMessages();
            } else if (choice.equals("2")) {
                System.out.println("This feature is coming soon.");
            } else if (choice.equals("3")) {
                running = false;
                System.out.println("Thank you for using QuickChat. Goodbye!");
            } else {
                System.out.println("Invalid choice. Please enter 1, 2 or 3.");
            }
        }

        input.close();
    }

    // Ask the user to register.
    private void registerUser() {
        System.out.println("========== REGISTRATION ==========");

        System.out.print("Enter your first name: ");
        String firstName = input.nextLine();

        System.out.print("Enter your last name: ");
        String lastName = input.nextLine();

        // Create the Login object with the user's name.
        user = new Login(firstName, lastName);

        String result = "";

        // Repeat until the registration details are correct.
        while (!result.equals(Login.MSG_SUCCESS)) {
            System.out.println("\nUsername must contain an underscore "
                    + "and have no more than 5 characters.");
            System.out.print("Create username: ");
            String username = input.nextLine();

            System.out.println("Password must be at least 8 characters "
                    + "and contain a capital letter, a number and a special character.");
            System.out.print("Create password: ");
            String password = input.nextLine();

            System.out.println("Cellphone must start with +27 and have 9 more digits.");
            System.out.print("Enter cellphone number: ");
            String cellphone = input.nextLine();

            result = user.registerUser(
                    username, password, cellphone, firstName, lastName);

            System.out.println(result);

            if (!result.equals(Login.MSG_SUCCESS)) {
                System.out.println("Please try again.");
            }
        }
    }

    // Ask the user to log in.
    private void loginUser() {
        System.out.println("\n========== LOGIN ==========");

        boolean loggedIn = false;

        // Repeat until the username and password are correct.
        while (!loggedIn) {
            System.out.print("Enter your username: ");
            String username = input.nextLine();

            System.out.print("Enter your password: ");
            String password = input.nextLine();

            String result = user.returnLoginStatus(username, password);
            System.out.println(result);

            loggedIn = user.isLoginSuccessful();

            if (!loggedIn) {
                System.out.println("Please try again.\n");
            }
        }
    }

    // Display the main menu.
    private void showMenu() {
        System.out.println("\n========== QUICKCHAT MENU ==========");
        System.out.println("1. Send Messages");
        System.out.println("2. Coming Soon");
        System.out.println("3. Quit");
        System.out.print("Choose an option: ");
    }

    // Create and process the number of messages chosen by the user.
    private void sendMessages() {
        int numberOfMessages = askHowManyMessages();

        // Repeat once for every message.
        for (int count = 1; count <= numberOfMessages; count++) {
            System.out.println("\nMessage " + count + " of " + numberOfMessages);

            String recipient = askForRecipient();
            String text = askForMessage();

            Message message = new Message(recipient, text);

            System.out.println("\nMessage details:");
            System.out.println(message);

            System.out.println("\nWhat would you like to do?");
            System.out.println("1. Send");
            System.out.println("2. Disregard");
            System.out.println("3. Store");
            System.out.print("Enter your choice: ");

            String choice = input.nextLine();

            if (choice.equals("1")) {
                sentMessages.add(message);
                System.out.println("Message sent successfully.");
            } else if (choice.equals("2")) {
                System.out.println("Message disregarded.");
            } else if (choice.equals("3")) {
                storedMessages.add(message);
                System.out.println("Message stored successfully.");
            } else {
                System.out.println("Invalid choice. Message was not saved.");
            }
        }

        System.out.println("\nMessages sent: " + sentMessages.size());
        System.out.println("Messages stored: " + storedMessages.size());
    }

    // Ask how many messages the user wants to create.
    private int askHowManyMessages() {
        while (true) {
            System.out.print("How many messages do you want to create? ");
            String answer = input.nextLine();

            try {
                int number = Integer.parseInt(answer);

                if (number > 0) {
                    return number;
                }

                System.out.println("Please enter a number greater than zero.");
            } catch (NumberFormatException error) {
                System.out.println("Please enter a whole number, such as 2.");
            }
        }
    }

    // Ask for a valid South African cellphone number.
    private String askForRecipient() {
        String recipient = "";

        while (!recipient.matches("\\+27[0-9]{9}")) {
            System.out.print("Enter recipient cellphone (+27 followed by 9 digits): ");
            recipient = input.nextLine();

            if (!recipient.matches("\\+27[0-9]{9}")) {
                System.out.println("Invalid cellphone number. Try again.");
            }
        }

        return recipient;
    }

    // Ask for a message that is between 1 and 250 characters long.
    private String askForMessage() {
        String text = "";

        while (text.length() == 0 || text.length() > 250) {
            System.out.print("Enter your message (1 to 250 characters): ");
            text = input.nextLine().trim();

            if (text.length() == 0) {
                System.out.println("The message cannot be empty.");
            } else if (text.length() > 250) {
                System.out.println("The message is too long. Please shorten it.");
            }
        }

        return text;
    }
}
