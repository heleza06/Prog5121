package poe.part.pkg1;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class MessagesTest {

    private static final String RECIPIENT = "+27718693002";
    private static final String TEXT = "Hi Mike, can you join us for dinner tonight";
    private Messages message;

    @Before
    public void setUp() {
        message = new Messages(0, RECIPIENT, TEXT);
    }

    @After
    public void tearDown() {
        message = null;
    }

    private String stringOfLength(int length) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            sb.append('a');
        }
        return sb.toString();
    }

    @Test
    public void testCheckMessageID() {
        assertTrue("Message ID should be no more than ten characters", message.checkMessageID());
        assertEquals("Message ID should be exactly ten digits", 10, message.getMessageID().length());
        assertTrue("Message ID should contain digits only", message.getMessageID().matches("[0-9]{10}"));
    }

    @Test
    public void testCheckRecipientCell() {
        assertTrue("Valid number should return true", Messages.checkRecipientCell("+27718693002"));
        assertTrue("Valid number should return true", Messages.checkRecipientCell("+27838968976"));
        assertFalse("Missing international code should return false", Messages.checkRecipientCell("08966553"));
        assertFalse("Local format should return false", Messages.checkRecipientCell("0718693002"));
        assertFalse("Missing plus sign should return false", Messages.checkRecipientCell("27718693002"));
        assertFalse("Code only should return false", Messages.checkRecipientCell("+27"));
        assertFalse("Too many digits should return false", Messages.checkRecipientCell("+277186930021234"));
        assertFalse("Letters should return false", Messages.checkRecipientCell("+2771869abcd"));
        assertFalse("Null should return false", Messages.checkRecipientCell(null));
    }

    @Test
    public void testCheckMessageLength() {
        assertEquals("Message ready to send.", Messages.checkMessageLength(TEXT));
        assertEquals("Message ready to send.", Messages.checkMessageLength(stringOfLength(250)));
        assertEquals("Message exceeds 250 characters by 1, please reduce size.", Messages.checkMessageLength(stringOfLength(251)));
        assertEquals("Message exceeds 250 characters by 10, please reduce size.", Messages.checkMessageLength(stringOfLength(260)));
    }

    @Test
    public void testCreateMessageHash() {
        String idStart = message.getMessageID().substring(0, 2);
        assertEquals(idStart + ":0:HITONIGHT", message.getMessageHash());
        assertEquals(message.getMessageHash(), message.CreateMessageHash());
        Messages third = new Messages(3, RECIPIENT, TEXT);
        assertEquals(third.getMessageID().substring(0, 2) + ":3:HITONIGHT", third.getMessageHash());
        Messages oneWord = new Messages(1, RECIPIENT, "Hello");
        assertEquals(oneWord.getMessageID().substring(0, 2) + ":1:HELLO", oneWord.getMessageHash());
        Messages spaced = new Messages(2, RECIPIENT, "  Hi   there!  ");
        assertEquals(spaced.getMessageID().substring(0, 2) + ":2:HITHERE", spaced.getMessageHash());
    }

    @Test
    public void testSentMessage() {
        int before = Messages.returnTotalMessages();
        assertEquals("Message successfully sent.", message.sentMessage(Messages.SEND));
        assertEquals(before + 1, Messages.returnTotalMessages());
        assertEquals("Message disregarded.", message.sentMessage(Messages.DISREGARD));
        assertEquals(before + 1, Messages.returnTotalMessages());
        assertEquals("Message successfully stored.", message.sentMessage(Messages.STORE));
        assertEquals(before + 1, Messages.returnTotalMessages());
        assertEquals("Invalid choice. Please enter 1, 2 or 3.", message.sentMessage(9));
        assertEquals(before + 1, Messages.returnTotalMessages());
    }

    @Test
    public void testReturnTotalMessages() {
        int before = Messages.returnTotalMessages();
        message.sentMessage(Messages.SEND);
        new Messages(1, RECIPIENT, "Second message").sentMessage(Messages.SEND);
        new Messages(2, RECIPIENT, "Third message").sentMessage(Messages.SEND);
        assertEquals(before + 3, Messages.returnTotalMessages());
    }

    @Test
    public void testPrintMessage() {
        String details = message.printMessage();
        assertTrue(details.contains(message.getMessageID()));
        assertTrue(details.contains(message.getMessageHash()));
        assertTrue(details.contains(RECIPIENT));
        assertTrue(details.contains(TEXT));
    }

    @Test
    public void testGetters() {
        assertEquals(0, message.getMessageNumber());
        assertEquals(RECIPIENT, message.getRecipient());
        assertEquals(TEXT, message.getMessageText());
    }
}
